#ifndef VARIABLESYMB_H
#define VARIABLESYMB_H

#include "ExprSymb.h"


class VariableSymb : public ExprSymb
{
    public:
        VariableSymb();
        virtual ~VariableSymb();

    protected:

    private:
};

#endif // VARIABLESYMB_H
