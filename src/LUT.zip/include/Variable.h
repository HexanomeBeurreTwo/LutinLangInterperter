#ifndef VARIABLE_H
#define VARIABLE_H

#include <iostream>
#include "ExprSymb.h"
using namespace std;


class Variable : public ExprSymb
{
    public:
        Variable(string n):ExprSymb(VAR),name(n){};
        virtual ~Variable();
        void print();

    protected:

    private:
        string name;
};

#endif // VARIABLE_H
