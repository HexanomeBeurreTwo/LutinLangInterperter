#include "Variable.h"

Variable::~Variable()
{
    //dtor
}

void Variable::print(){

}
