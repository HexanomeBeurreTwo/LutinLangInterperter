#include "Symbol.h"

Symbol::~Symbol(){}

