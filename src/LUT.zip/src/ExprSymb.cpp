#include "ExprSymb.h"


ExprSymb::~ExprSymb()
{
    //dtor
}

void ExprSymb::print(){

}
