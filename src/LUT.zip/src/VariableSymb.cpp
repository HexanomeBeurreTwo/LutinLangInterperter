#include "VariableSymb.h"

VariableSymb::VariableSymb()
{
    //ctor
}

VariableSymb::~VariableSymb()
{
    //dtor
}
