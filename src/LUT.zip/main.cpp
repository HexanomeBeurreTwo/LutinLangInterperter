

#include <iostream>
using namespace std;

#include "AffectSymb.h"
#include "ExprSymb.h"
#include "Variable.h"

int main() {
    ExprSymb e;
    Variable v("A");
	AffectSymb symbole(e,v) ;
	symbole.print();

	return 0;

}


